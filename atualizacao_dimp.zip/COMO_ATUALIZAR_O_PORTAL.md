# Guia Técnico de Atualização e Manutenção — Portal BPM SESAP/RN

Este documento orienta a equipe técnica e acadêmica do Projeto BPM SESAP/RN na inclusão, revisão e governança dos processos, POPs, manuais, modelos e relatórios no Portal Institucional.

---

## 1. Arquitetura Modular de Dados

Para garantir alta velocidade de carregamento, responsividade, compatibilidade com **GitHub Pages** e funcionamento em modo offline/local (`file:///`), os dados do portal estão organizados de forma desacoplada do HTML:

```
DIMP-main/
├── dados/
│   ├── processos.json      # Catálogo estruturado dos processos das 5 frentes
│   ├── modelos.json        # Modelos institucionais padronizados (Canva e minutas)
│   ├── pops_manuais.json   # Coleção de POPs e Manuais da SESAP/RN
│   ├── documentos.json     # Catálogo de relatórios técnicos e executivos
│   └── capacitacoes.json   # Base de conhecimento e materiais de apoio
├── js/
│   ├── dados-portal.js     # Objeto global window.DIMP_DATA (permite abertura local sem CORS)
│   └── script.js           # Funções de renderização, filtros, modal simplificado e interatividade
├── build_data.py           # Script automatizado para compilar os dados
├── index.html              # Estrutura institucional em 9 seções padronizadas
└── css/style.css           # Identidade visual, animação float e responsividade
```

---

## 2. Estrutura da Página Individual do Processo (Modal)

Ao clicar em **"Visualizar Processo"**, o portal exibe uma visão focada e compacta em 5 blocos:
1. **Identificação do Processo:** Nome, Código (`COM-xxx`, `AQU-xxx`, `MAN-xxx`, `CUS-xxx`, `SIS-xxx`, `HIS-xxx`), Frente de Trabalho e Unidade Administrativa.
2. **Descrição e Escopo do Processo:** Finalidade, abrangência e limites das atividades envolvidas.
3. **Objetivo Institucional:** Contribuição do processo para as atividades da SESAP/RN.
4. **Duas Caixas de Acesso em Destaque (Lado a Lado no Desktop / Empilhadas no Mobile):**
   - **Caixa 1 — Fluxograma do Processo:** Botão único institucional **"Acessar Fluxograma"** direcionando para o fluxograma interativo no Bizagi.
   - **Caixa 2 — Base de Conhecimento:** Botão de acesso ao documento completo do processo (relatório técnico detalhado ou modelo institucional padronizado).
5. **Base Normativa e Legal & Situação de Validação:** Legislações aplicáveis e status oficial confirmado (*Em documentação, Aguardando validação, Validado, Em revisão, Implantado*).

---

## 3. Gestão por Processos em Duas Abas

A seção Gestão por Processos foi simplificada em apenas duas abas principais:
- **Aba 1 — Modelos de Documentos:** Templates oficiais para documentação de processos, manuais, POPs, fichas de processos, matrizes de indicadores, matrizes de riscos e minutas contratuais.
- **Aba 2 — POPs e Manuais da SESAP/RN:** Biblioteca pesquisável e filtrável por frente e tipo de documento, reunindo todos os POPs e manuais desenvolvidos pelo projeto.

---

## 4. Painel de Indicadores e Múltiplos Dashboards

O Painel de Indicadores do portal DIMP permite visualizar todos os painéis no mesmo local (via alternância dinâmica no cabeçalho do painel) com opção de abertura em tela cheia e em nova aba para o painel selecionado:
- **Painel do Projeto DIMP (Streamlit):** `https://dashprojetosesap.streamlit.app/`
- **Dashboard de Aquisições:** `https://sesapbpm.github.io/dashboard_aquisi-es_2.0_atualizado/`
- **Dashboard de Contratos:** `https://sesapbpm.github.io/DashboardContratos/`
- **Dashboard de Central de Compras (PCA):** `https://sesapbpm.github.io/pca-sesap-dashboard/`

---

## 5. Como Cadastrar um Novo Processo ou POP

1. Abra o arquivo `build_data.py`.
2. Adicione a entrada na lista `processos` ou `pops_manuais`.
3. Execute o script de compilação:
   ```bash
   python build_data.py
   ```
4. Os arquivos JSON na pasta `dados/` e o script `js/dados-portal.js` serão atualizados de forma automática e síncrona.

---

## 5. Publicação no GitHub Pages

Após validar as alterações localmente abrindo `index.html`, basta realizar o commit e push dos arquivos:
```bash
git add .
git commit -m "feat: atualizacao do catalogo de processos e documentos"
git push origin main
```
O workflow estático do GitHub Pages (`.github/workflows/static.yml`) publicará automaticamente a versão atualizada no endereço:
`https://sesapbpm.github.io/DIMP/`
